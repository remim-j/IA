README

1) Inclure le jeu de donn�es "YearPredictionMSD.txt" dans le sous-dossier "Parser Java".
2) Lancer le parser Java "DataIA.java".
3) 2 fichiers CSV viennent d'�tre cr��s : "datatrain.csv" et "datatest.csv".
D�placer-les dans le sous-dossier "Scripts R".
4) Lancer les scripts R pour obtenir la pr�diction de l'ann�e de sortie.